import inquirer from "inquirer";
const answers = await inquirer.prompt([
    {
        name: "Sentences",
        type: "input",
        message: "Enter your Sentence to count the words: "
    }
]);
const words = answers.Sentences.trim().split("");
console.log(`Your Sentence word count is: ${words.length}`);
