import inquirer from "inquirer"
import prompt from "inquirer/lib/ui/prompt.js"

const answers : {
    Sentences: string,
} = await inquirer.prompt([
    {
        name: "Sentences",
        type: "input",
        message: "Enter your Sentence to count the words: "
    }
]);

const words = answers.Sentences.trim().split("")
console.log(`Your Sentence word count is: ${words.length}`);